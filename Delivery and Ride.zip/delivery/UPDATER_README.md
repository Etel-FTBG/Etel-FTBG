# 🔄 ETEL Delivery File Updater System

## What is This?

The File Updater System is a built-in tool that allows you to update individual files in your ETEL Delivery application **without having to re-upload the entire system** through cPanel or FTP.

## Why Use It?

### Before (Traditional Method) ❌
1. Download entire delivery folder from server
2. Edit files locally
3. Re-upload entire folder via cPanel/FTP
4. Wait for all files to upload (slow!)
5. Risk overwriting other changes
6. No automatic backups

### After (With File Updater) ✅
1. Login to admin panel
2. Click the file you want to edit
3. Make changes in browser
4. Click Save
5. Done! (Automatic backup created)

**Time saved: 90%** ⚡

## Key Features

### 🎯 Selective Updates
- Update only the files you need
- No need to touch other files
- Faster and safer

### 💾 Automatic Backups
- Every change creates a backup
- Restore previous versions anytime
- Never lose your work

### 🔒 Security
- Admin-only access
- Protected system files
- File type validation
- Path security

### 📁 File Browser
- Visual file tree
- Search functionality
- File information
- Easy navigation

### ✏️ Built-in Editor
- Edit files in browser
- Syntax highlighting
- Unsaved changes warning
- Real-time editing

### ⬆️ File Upload
- Upload new files
- Replace existing files
- Drag and drop support
- Multiple file types

## Quick Start

### Step 1: Access the Updater

```
1. Login as admin
2. Go to Admin Panel
3. Click "System Settings" in sidebar (⚙️ icon)
4. You'll see the File Updater interface
```

### Step 2: Update a File

**Option A: Edit in Browser**
```
1. Click "📁 File Browser" tab
2. Navigate to your file (e.g., js/core.js)
3. Click the file to open editor
4. Make your changes
5. Click "💾 Save Changes"
6. Confirm → Done!
```

**Option B: Upload File**
```
1. Click "⬆️ Upload File" tab
2. Enter target path (e.g., js/core.js)
3. Select your file from computer
4. Click "⬆️ Upload & Replace"
5. Confirm → Done!
```

### Step 3: Verify Changes

```
1. Open your site in browser
2. Hard refresh (Ctrl+Shift+R)
3. Check if changes are applied
4. Open console (F12) to check for errors
```

## Common Use Cases

### 1. Fix a JavaScript Bug

**Scenario**: There's a bug in `core.js`

**Steps**:
1. File Browser → js → core.js
2. Find the bug (use Ctrl+F to search)
3. Fix the code
4. Save
5. Refresh browser to test

**Time**: 2 minutes ⚡

### 2. Update API Endpoint

**Scenario**: Need to add a new API endpoint

**Steps**:
1. File Browser → api → api.php
2. Add your new endpoint code
3. Save
4. Test with API call

**Time**: 3 minutes ⚡

### 3. Change Styles

**Scenario**: Update button colors

**Steps**:
1. File Browser → css → etel.css
2. Modify CSS rules
3. Save
4. Hard refresh browser

**Time**: 1 minute ⚡

### 4. Update HTML Content

**Scenario**: Change text on login page

**Steps**:
1. File Browser → login.html
2. Find and update text
3. Save
4. Refresh page

**Time**: 2 minutes ⚡

## File Structure

```
delivery/
├── api/
│   ├── api.php              ← Main API (protected)
│   ├── updater-api.php      ← Updater API (protected)
│   └── *.php                ← Other APIs (editable)
├── js/
│   ├── core.js              ← Core JavaScript (editable)
│   └── *.js                 ← Other scripts (editable)
├── css/
│   └── etel.css             ← Styles (editable)
├── assets/
│   └── images/              ← Images (not editable)
├── backups/                 ← Auto-created backups
├── *.html                   ← HTML pages (editable)
└── *.json                   ← Config files (editable)
```

## Supported File Types

| Type | Extension | Editable | Uploadable |
|------|-----------|----------|------------|
| PHP | .php | ✅ | ✅ |
| HTML | .html | ✅ | ✅ |
| JavaScript | .js | ✅ | ✅ |
| CSS | .css | ✅ | ✅ |
| JSON | .json | ✅ | ✅ |
| Markdown | .md | ✅ | ✅ |
| Text | .txt | ✅ | ✅ |
| SQL | .sql | ✅ | ✅ |
| Images | .png, .jpg | ❌ | ❌ |
| Binary | .pdf, .zip | ❌ | ❌ |

## Backup System

### How It Works

1. **Before any change**, the system creates a backup
2. Backup is saved in `/backups/` folder
3. Backup filename includes timestamp
4. You can restore from any backup
5. Old backups can be deleted manually

### Backup Naming Convention

```
YYYY-MM-DD_HHMMSS_original_filename

Example:
2026-05-24_143022_js_core.js

Breakdown:
- 2026-05-24: Date
- 143022: Time (14:30:22)
- js_core.js: Original file (/ replaced with _)
```

### Restoring from Backup

```
1. Go to "💾 Backups" tab
2. Find the backup you want
3. Click "↩️ Restore"
4. Confirm
5. File is restored!
```

### Managing Backups

- **View**: See all backups with dates
- **Restore**: Revert to previous version
- **Delete**: Remove old backups to save space

**Tip**: Keep at least 3-5 recent backups of important files!

## Security Features

### 1. Authentication
- Only admin users can access
- Token-based authentication
- Session validation

### 2. Protected Files
These files cannot be modified:
- `api/api.php` (main API)
- `api/updater-api.php` (updater itself)
- `.htaccess` (server config)

**Why?** To prevent accidental system breakage.

### 3. File Type Validation
- Only allowed file types can be uploaded
- Prevents malicious file uploads
- Protects against security risks

### 4. Path Validation
- Directory traversal protection
- Cannot access files outside system
- Prevents unauthorized file access

### 5. Automatic Backups
- Every change creates a backup
- Easy rollback if needed
- No data loss

## Best Practices

### ✅ DO

1. **Test changes immediately**
   - Make change → Save → Test
   - Keep browser console open (F12)
   - Check for errors

2. **Make small changes**
   - One feature at a time
   - Easier to debug
   - Easier to rollback

3. **Keep recent backups**
   - Don't delete last 5 backups
   - Keep working versions
   - Safety net for mistakes

4. **Update during low traffic**
   - Off-peak hours
   - Less user impact
   - Time to test

5. **Document changes**
   - Keep notes
   - Track what you changed
   - Helps with debugging

### ❌ DON'T

1. **Don't make multiple changes at once**
   - Hard to debug
   - Hard to rollback
   - Risky

2. **Don't delete all backups**
   - Keep safety net
   - You might need them
   - Disk space is cheap

3. **Don't edit protected files**
   - Use FTP for those
   - System protection
   - Prevents breakage

4. **Don't skip testing**
   - Always verify changes
   - Check console for errors
   - Test on different devices

5. **Don't update during peak hours**
   - Risk user experience
   - Hard to test properly
   - Stressful if issues occur

## Troubleshooting

### Problem: Changes Not Showing

**Symptoms**: Saved changes but site looks the same

**Solutions**:
1. Hard refresh: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)
2. Clear browser cache
3. Try incognito/private window
4. Wait 1-2 minutes for server cache
5. Check if you edited the correct file

### Problem: Cannot Save File

**Symptoms**: "Failed to write file" error

**Solutions**:
1. Check file permissions (should be 644)
2. Check disk space (need at least 100MB free)
3. Check if directory exists
4. Try uploading instead of editing
5. Contact hosting support

### Problem: Site Broken After Update

**Symptoms**: White screen, errors, site not loading

**Solutions**:
1. **Don't panic!** 😊
2. Go to Backups tab immediately
3. Find most recent backup
4. Click Restore
5. Verify site works
6. Review what you changed
7. Try again with smaller change

### Problem: File Not Found

**Symptoms**: "File not found" error

**Solutions**:
1. Check exact file path
2. Check case sensitivity (Linux is case-sensitive)
3. Verify file exists in File Browser
4. Try refreshing File Browser
5. Check if file was deleted

### Problem: Backup Not Found

**Symptoms**: Cannot restore backup

**Solutions**:
1. Check if backup exists in `/backups/` folder
2. Check directory permissions
3. Check disk space
4. Backup might have been deleted
5. Use FTP to check backups folder

## Advanced Tips

### Keyboard Shortcuts

In the editor:
- `Ctrl+F`: Find text
- `Ctrl+H`: Find and replace (browser dependent)
- `Ctrl+Z`: Undo
- `Ctrl+Y`: Redo
- `Ctrl+A`: Select all

### Search Tips

In File Browser search:
- Type filename: `core.js`
- Type path: `api/`
- Type extension: `.php`
- Partial match works: `cor` finds `core.js`

### Bulk Updates

For multiple files:
1. **Option A**: Update one by one through updater
2. **Option B**: Use FTP for bulk upload
3. **Option C**: Prepare locally, upload via Upload tab

### Emergency Rollback

If site is completely broken:
1. Access via FTP/cPanel
2. Go to `/backups/` folder
3. Find the backup file
4. Copy it to original location
5. Rename to remove timestamp prefix

## System Requirements

### Server Requirements
- PHP 5.6 or higher
- Write permissions on system directory
- At least 100MB free disk space
- MySQL/MariaDB database

### Browser Requirements
- Modern browser (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- Cookies enabled
- Minimum 1024x768 resolution

## Limitations

1. **File Size**: Files larger than 10MB may timeout
2. **Binary Files**: Cannot edit images, PDFs, etc.
3. **Protected Files**: Some files cannot be modified
4. **Concurrent Edits**: No multi-user editing
5. **Version Control**: No Git integration (manual)
6. **Syntax Checking**: No real-time syntax validation

## FAQ

### Q: Is it safe to use?
**A**: Yes! Every change creates a backup automatically. You can always restore.

### Q: Can I break my site?
**A**: Unlikely. Protected files prevent major breakage. If something goes wrong, restore from backup.

### Q: Do I need FTP anymore?
**A**: For most updates, no. But keep FTP for:
- Protected files
- Bulk uploads
- Emergency access
- Binary files (images)

### Q: How much disk space do backups use?
**A**: Depends on file sizes. Typically 10-50MB for text files. Monitor and delete old backups.

### Q: Can multiple admins edit at once?
**A**: No. Last save wins. Coordinate with team to avoid conflicts.

### Q: What if I delete a file by mistake?
**A**: Restore from backup! That's why we keep them.

### Q: Can I edit database files?
**A**: No. Use phpMyAdmin for database changes.

### Q: Does it work on mobile?
**A**: Yes, but desktop is recommended for better experience.

## Support

### Getting Help

1. **Check Documentation**
   - FILE_UPDATER_GUIDE.md (detailed)
   - UPDATER_QUICK_START.txt (quick reference)
   - This README

2. **Check Console**
   - Open browser console (F12)
   - Look for error messages
   - Copy error for support

3. **Check Backups**
   - Can you restore?
   - When was last working version?

4. **Check Permissions**
   - File permissions: 644
   - Directory permissions: 755
   - Owner: correct user

### Contact

For critical issues:
- Use FTP/cPanel for manual restore
- Check `/backups/` folder
- Contact hosting support if needed

## Version History

### v1.0 (2026-05-24)
- ✨ Initial release
- 📁 File browser with tree view
- ✏️ Built-in code editor
- ⬆️ File upload functionality
- 💾 Automatic backup system
- 🔄 Backup restore feature
- 🔒 Security features
- 📊 System info dashboard

## Roadmap

Future enhancements planned:
- [ ] Syntax highlighting in editor
- [ ] Code formatting
- [ ] Multiple file upload
- [ ] Diff viewer for changes
- [ ] Git integration
- [ ] Scheduled backups
- [ ] Backup compression
- [ ] File comparison tool
- [ ] Change history log
- [ ] Real-time collaboration
- [ ] Mobile app

## Credits

Developed for ETEL Delivery System
Part of the ETEL Group ecosystem

---

**Remember**: With great power comes great responsibility! 
Always test changes and keep backups. 🛡️

Happy updating! 🚀
