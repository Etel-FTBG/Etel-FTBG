# 05 — Security Controls (Implementation Level)

This section documents the concrete implementation-level security controls
in the current codebase. It is a technical companion to
`docs/INSA_FINDINGS.md`, which is the audit narrative (what was checked,
what was found, what was fixed); this file restates the *resulting design*
for LLD purposes.

## 1. Authentication

- Custom signed bearer-token scheme (`api/boot.php`), not PHP sessions, not JWT.
- `gen_token($user_id, $version)`: packs `user_id:issued_at:token_version`,
  HMAC-SHA256-signs with `TOKEN_SECRET_FINAL`, base64-encodes.
- `verify_token()`: hard 7-day lifetime; malformed tokens rejected closed;
  signature compared with timing-safe `hash_equals()`.
- `get_auth_user()`: additionally compares the token's embedded
  `token_version` against the live `users.token_version` column — a
  mismatch invalidates the token immediately, independent of the 7-day
  window. This is the server-side revocation mechanism (no token blacklist
  table needed).
- No silent token refresh exists anywhere — expiry always produces a clean
  401 requiring re-login.
- `logout` calls a helper that increments `token_version`, invalidating
  every outstanding token for that user across every device in one write.
- Exactly one cookie-based auth surface exists in the whole codebase:
  `api/etelid_auth.php` (bridging to EtelID's SSO), using
  `Secure` (conditional on real HTTPS detection) + `HttpOnly` +
  `SameSite=Lax` + an 8-hour inactivity timeout. Verified: zero other
  `setcookie()` calls anywhere in `delivery/`.
- Service-to-service auth (`AgentController`, `NfcController`, EtelID
  member-lookup actions) uses a separate shared-secret scheme
  (`ETELID_SERVICE_KEY`, `hash_equals()`), independent of the bearer-token
  system, with a `?key=` query-param fallback alongside the header (some
  shared-hosting FastCGI configs strip custom `X-*` headers).

## 2. Authorization

- Ownership checks: courier/customer/service-giver-scoped actions verify
  the caller's own resolved profile/business/ride owns the row being
  accessed (e.g. `check_pickup_confirmation` / `check_delivery_confirmation`
  were found missing this check and fixed — see INSA_FINDINGS.md §1).
- Role checks: `register` hard-restricts self-registration to
  customer/courier only; `admin_etelid_login` never trusts a
  client-supplied role.
- Driver onboarding gate: `rides_require_onboarded()` — a single shared
  function gating every driver-privileged ride action on
  `ride_drivers.onboarded = 1`, added specifically to close a fraud/safety
  gap where any authenticated role could otherwise call these actions.
- Admin capability model: every `AdminController` (and related) action is
  gated through `require_admin($pdo, 'capability')`, checking both the
  `admin` role and a specific capability string (e.g. `orders.manage`,
  `finance.view`, `equity.manage`, `owner.only`, `system.reset`) against the
  `role_permissions` table — `admin` is not a monolithic privilege tier.

## 3. Injection Prevention

- All database access uses PDO parameterized queries with
  `PDO::ATTR_EMULATE_PREPARES => false`.
- Verified: zero SQL injection findings across 552 reviewed
  `prepare`/`query`/`exec` call sites (INSA_FINDINGS.md §2).
- Any dynamic column/table name always traces to a hardcoded whitelist,
  never to request input; `LIMIT`/date-range values are always
  `intval()`'d or selected from fixed fragments.

## 4. Output Encoding (XSS Prevention)

- All user-controllable values rendered via `innerHTML` or equivalent are
  passed through `escapeHtml()`/`esc()` helpers.
- 6 stored-XSS sinks were found and fixed during the audit across
  customer/courier/service-giver/admin/driver/ride front-ends
  (INSA_FINDINGS.md §3) — all now escaped.
- `escUrl()` helper rejects `javascript:` / `vbscript:` / `data:text/html`
  schemes on any raw image/photo URL placed into an attribute.
- Fixes are propagated into the versioned release bundles
  (`js/releases/{app}/{version}/`), not just source — a source-only fix
  does not reach production without a bundle rebuild.

## 5. File Upload Handling

- `upload.php`: content-sniffed MIME-type whitelist (not filename
  extension alone), 5MB cap (8MB for admin branding uploads), whitelisted
  destination folders, fully server-generated filenames (client filename
  never used) — prevents path traversal and executable-content hosting.
- Admin file-deploy/Updater tool uses the same pattern via
  `etel_safe_rel_path()` / `etel_canonicalize()`.
- Document library downloads: `.html`/`.js` files are always served with
  `Content-Disposition: attachment` regardless of requested disposition,
  derived from the actual on-disk file extension (not a possibly-stale DB
  column) — closes a privilege-escalation path where a stored HTML
  document, if rendered inline in a `blob:` iframe, could read the
  viewer's bearer token from `localStorage` (INSA_FINDINGS.md §10).

## 6. Rate Limiting

- `login_attempts` table + `rate_limit_check()` / `rate_limit_fail()` /
  `rate_limit_clear()` helpers in `boot.php`, applied to `login` and
  `sg_login`, keyed by `login:<phone>` / `sg_login:<phone>`.

## 7. Error Handling & Logging

- ~60 empty/comment-only catch blocks audited across 62 PHP files; an
  established intentional soft-fail pattern for most.
- 9 catch blocks across 5 files were found to silently swallow
  non-trivial failures and had `error_log()` added (updater audit-log
  insert, courier auto-provisioning, login-attempt rate-limit writes,
  admin dashboard stats, SG lat/lng update, auto-dispatch notification,
  `change_password` token re-fetch, SG-login lookup).
- `change_password`'s token-refetch failure now hard-fails
  (`require_relogin: true`) rather than soft-degrading with a possibly
  stale token.

## 8. Web-Server-Level Controls

- `Options -Indexes` set repo-wide; `api/backups/` (runtime deploy
  backups created by the Updater tool) additionally has its own explicit
  `Require all denied` `.htaccess` (fixed — previously relied only on the
  directory-listing block, not an access block).
- Updater tool credentials load from `.env`/`getenv()` and fail closed
  (HTTP 503) if unset — no default password, no silent bypass.
- `updater-api.php` CORS is scoped to `ethelmarket.com`, not a wildcard.

## 9. Payment Integrity

- Driver Etel Money top-ups: `tx_ref` is server-verified via
  `etel_pay_verify_tx()` against EtelPay before the top-up row is even
  created as `pending`; balance only moves after a **second**, independent
  admin approval step (`admin_approve_etel_topup`) — a single compromised
  or spoofed `tx_ref` cannot move funds without both checks passing.
- Bank-transfer order payments require admin verification
  (`bank_payments.verified_by/at`) before being treated as paid.

## 10. Known Open Items (carried from INSA_FINDINGS.md §7, both fixed)

| Item | Status |
|---|---|
| `api/backups/` web-accessibility | Fixed — dedicated deny-all `.htaccess` added |
| Hardcoded admin password risk in Updater tool | Verified already fixed in a prior session — credentials load from environment, fail closed |
