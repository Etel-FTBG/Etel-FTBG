# 02 — API Contracts

## Dispatch model

Single entrypoint: `api/boot.php`. Every request (JSON POST body or GET query)
carries an `action` field, dispatched via a switch/require to one of 17
controller files under `api/controllers/`. There is no REST-style URL
routing — one physical endpoint, ~325 logical actions.

**The complete, verified action-by-action table (action name, HTTP method,
required role, required capability where applicable, file+line reference)
is maintained in `docs/INSA_FINDINGS.md`, Section 8 (lines 519–946).** That
table was produced by directly auditing every controller for its access
checks and is the authoritative source — it is referenced here rather than
duplicated, to avoid the two documents drifting out of sync.

## Controller inventory (action counts)

| Controller | Actions | Domain |
|---|---|---|
| `boot.php` (inline) | 31 | ping/config, admin quick-reads, SSE streams, password reset |
| `AuthController.php` | 6 | register, login, sg_login, etelid_login, admin_etelid_login, change_password |
| `AdminController.php` | 73 | Platform administration (largest surface) |
| `EquityController.php` | 18 | Investor cap table & profit distribution |
| `InvestorPortalController.php` | 2 | Legacy token-link investor portal |
| `SystemResetController.php` | 3 | Danger-zone full data wipe |
| `EqubController.php` | 19 | Rotating savings |
| `PlanningController.php` | 7 | Business/hiring plan |
| `PlatformEconomicsController.php` | 6 | Cost/growth assumptions |
| `DriverFuelController.php` | 4 | Driver fuel logs |
| `CourierFuelController.php` | 4 | Courier fuel logs |
| `PushController.php` | 3 | Web Push subscriptions |
| `AgentController.php` | 9 | EtelAI machine-to-machine booking |
| `OrderController.php` | 47 | Delivery order lifecycle |
| `ServiceGiverController.php` | 28 | Storefront operations |
| `RideController.php` | 65 | Ride-hailing lifecycle (largest file) |
| `NfcController.php` | 5 | EtelID NFC-tap bridge |
| `DocumentsController.php` | 7 (+2 standalone multipart endpoints) | Internal document library |

**Total: ~325 actions across 17 controllers + boot.php inline actions.**

## Authentication schemes in use

1. **Bearer token** (most user-facing actions) — `Authorization: Bearer <token>`.
   Token = base64(`user_id:issued_at:token_version:hmac`), HMAC-SHA256 signed
   with `TOKEN_SECRET_FINAL`. 7-day hard expiry. `get_auth_user()` additionally
   compares the embedded `token_version` against the live `users.token_version`
   column for immediate revocation.
2. **Shared service key** (`AgentController`, `NfcController`, and a few
   `boot.php` EtelID-internal actions) — `hash_equals()` constant-time check
   against `ETELID_SERVICE_KEY`, sent as a header with a `?key=` query-param
   fallback (some shared-hosting FastCGI configs strip custom headers).
3. **Cookie session** (`api/etelid_auth.php` only) — bridges to EtelID's
   browser SSO; `Secure` (conditional on HTTPS), `HttpOnly`, `SameSite=Lax`,
   8-hour inactivity timeout. This is the only cookie-based auth surface in
   the entire `delivery/` codebase.

## Worked request/response examples

The following are reproduced from `docs/INSA_FINDINGS.md` §9, which contains
exact field names verified directly against the implementing code.

### `login`
```
POST /api/boot.php
{ "action": "login", "phone": "0912345678", "password": "••••••••" }

→ 200 OK
{ "success": true, "token": "<bearer token>", "user": { "id": 123, "name": "...", "role": "customer", ... } }

→ 401 (rate-limited or invalid credentials)
{ "success": false, "message": "Invalid phone or password" }
```

### `customer_create_order`
```
POST /api/boot.php   Authorization: Bearer <token>
{
  "action": "customer_create_order",
  "service_giver_id": 45,
  "items": [ { "item_id": 501, "qty": 2 }, ... ],
  "delivery_zone": "Tabor",
  "delivery_tier": "standard",
  "payment_method": "telebirr",
  "recipient_name": "...",
  "recipient_phone": "...",
  "delivery_lat": 7.06, "delivery_lng": 38.47
}

→ 200 OK
{ "success": true, "order": { "id": 9001, "order_code": "ORD-...", "fare_total": 145.00, "status": "pending", ... } }
```

### `book_ride`
```
POST /api/boot.php   Authorization: Bearer <token>
{
  "action": "book_ride",
  "vehicle_type": "car",
  "pickup_lat": 7.06, "pickup_lng": 38.47, "pickup_address": "...",
  "dropoff_lat": 7.08, "dropoff_lng": 38.49, "dropoff_address": "...",
  "payment_method": "cash",
  "quote_token": "<from ride_estimate_fare>"
}

→ 200 OK
{ "success": true, "ride": { "id": 3301, "status": "searching", "fare_estimate": 85.00, "expires_at": "..." } }
```

### `driver_topup_etel_money`
```
POST /api/boot.php   Authorization: Bearer <token>   (role=driver, onboarded=1 required)
{ "action": "driver_topup_etel_money", "amount": 500.00, "tx_ref": "EP-...", "receipt_image_url": "..." }

→ 200 OK
{ "success": true, "topup": { "id": 771, "status": "pending", "amount": 500.00 } }
```
Note: the balance is **not** credited on this response — `tx_ref` is
server-verified via `etel_pay_verify_tx()` before the row is even created as
`pending`, and a separate admin action (`admin_approve_etel_topup`) must
approve it before `ride_drivers.total_earnings`/wallet balance actually moves.

## Real-time / streaming interfaces

| Endpoint | Transport | Purpose |
|---|---|---|
| `sse_ride_status` | Server-Sent Events | Live ride status push to passenger/driver |
| `sse_driver_stream` | Server-Sent Events | Live driver location push |
| `sse_admin_delivery_system_test` / `sse_admin_system_test` | Server-Sent Events | Admin diagnostic streams |

## External interface contracts

| System | Actions/files | Auth |
|---|---|---|
| EtelID SSO | `etelid_login`, `admin_etelid_login` | User-driven redirect flow |
| EtelID NFC bridge | `NfcController.php` (5 actions) | Shared service key |
| EtelID members bridge | `etelid_members_list`, `etelid_member_detail` (boot.php) | Shared service key |
| EtelPay | `etel_pay_verify_tx()` call site in `RideController.php` | Server-to-server verification call |
| Telebirr | `telebirr_payments` flow in `OrderController.php` | Telebirr merchant API |
| Telegram | `api/telegram_webhook.php` | Bot token |
