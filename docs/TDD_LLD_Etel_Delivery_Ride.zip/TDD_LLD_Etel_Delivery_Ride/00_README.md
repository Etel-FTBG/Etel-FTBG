# Technical Design Document / Low-Level Design (TDD/LLD)
## Etel Delivery & Ride Platform — v1.0

Prepared for the INSA Security Audit submission via the Hibir platform.
Companion to the SRS and SDD documents.

## Contents

1. `01_Database_Schema.md` — full table inventory (migrations + inline runtime tables)
2. `02_API_Contracts.md` — controller/action inventory with method, access level, and worked request/response examples
3. `03_State_Machines.md` — ride and order lifecycle state machines
4. `04_Module_Breakdown.md` — file-level module map (controllers, lib helpers, front-end apps)
5. `05_Security_Controls.md` — implementation-level security mechanisms (auth, rate limiting, upload handling, capability checks)

All content in this package is derived directly from the production source code
at `/delivery/` in the Etel-FTBG repository, cross-verified against
`docs/INSA_FINDINGS.md` (the code-level security review prepared for the same
INSA submission). No content here is speculative — every claim is traceable to
a specific file, table, or action name in the codebase.
