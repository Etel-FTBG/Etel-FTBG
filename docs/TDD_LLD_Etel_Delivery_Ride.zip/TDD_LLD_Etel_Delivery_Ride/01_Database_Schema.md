# 01 — Database Schema

Two schema sources exist and are both authoritative for different purposes:

- **`api/migrations/001-057_*.sql`** — versioned, incremental, tracked via a
  `schema_migrations` table and applied by `api/migrate.php`.
- **`api/seeds/complete_migration.sql`** — a full v4.0.0 schema dump for
  fresh installs, defining 19 core tables.
- Several tables (notably the ride-hailing core) are created **idempotently
  at runtime** by controller code (`CREATE TABLE IF NOT EXISTS`), self-healed
  on existing installs via `rides_add_missing_cols()` in
  `api/lib/schema_helpers.php`.

## 1. Core tables (complete_migration.sql — 19 tables)

| Table | Key columns | Purpose |
|---|---|---|
| `users` | id, name, phone (unique), email, password_hash, `role`, lang, active, timestamps | Single identity table for every role |
| `couriers` | user_id, courier_code (unique), vehicle_type, plate_number, zone, status, last_lat/lng, rating, total_deliveries, referral_code | Delivery-app courier profile |
| `service_givers` | user_id, service_giver_code, business_name, service_type, zone, status, is_online, average_rating, total_earnings, bank_account | Storefront/business profile |
| `delivery_zones` | name (unique), base_fare, surge_active/mult, est_minutes, sort_order, active | Zone-based delivery pricing (12 Hawassa zones seeded) |
| `pricing_rules` | rule_key (unique), rule_value, description | Configurable pricing knobs (base_fare, per_km_rate, surge_multiplier, etc.) |
| `orders` | order_code (unique), customer_id, courier_id, service_giver_id, from/to_zone, package_type, delivery_tier, payment_method/status, fare fields, status, pickup/delivery lat/lng, delivery_photo_url | Core delivery order entity |
| `order_ratings` | order_id (unique), customer_id, stars, courier_rating, food_rating, comment | Post-delivery rating |
| `order_assignments` | order_id, service_giver_id, status, pickup/delivery QR flags+timestamps | SG-side assignment tracking |
| `patch_log` | version, applied_at, applied_by, notes | Deploy audit trail (Updater tool) |
| `items` / `order_items` | item_code, price, stock, name_am/description_am | SG catalog + order line items |
| `telebirr_payments` | user_id, order_id, amount, merchant/telebirr tx IDs, status, response_data JSON, retry_count | Telebirr payment tracking (redefined in migration 050) |
| `payment_retries` | attempt tracking | Telebirr retry log |
| `bank_payments` | bank, amount, reference_no, status, verified_by/at | Bank-transfer payment, admin-verified |
| `user_wallets` / `wallet_transactions` | balance, currency, credit/debit ledger with balance_after snapshot | Internal wallet ledger |
| `push_tokens` | legacy device token store | Superseded by `push_subscriptions` |
| `scheduled_orders` | customer_id, scheduled_at, repeat_daily, order_template JSON | Recurring order scheduling |
| `order_confirmations` | order_id, type (pickup/delivery), status, requested_by, responded_by, payment_confirmed | Two-party confirmation handshake |

## 2. Tables added by numbered migrations (001–057)

| Migration | Table(s)/change | Purpose |
|---|---|---|
| 001 | `login_attempts` | Brute-force/rate-limit tracking |
| 005 | `password_resets` | OTP-based reset flow |
| 006 | `users.token_version` | Bearer-token revocation counter |
| 007 | `ride_fare_rules` | Per-vehicle-type fare config |
| 008 | `delivery_zones` additions | base_fare/surge/est_minutes |
| 009 | `driver_announcements`, `driver_announcement_reads`, courier referral columns | Admin news + referral program |
| 010 | `ride_issues` | Passenger/driver-reported ride problems |
| 011 | `push_subscriptions` | Web Push (VAPID) subscriptions |
| 012 | `delivery_tiers`, `orders.delivery_tier` | Delivery tier options |
| 013 | `orders.delivery_photo_url` | Proof-of-delivery photo |
| 014 | `bank_accounts` | Platform's receiving bank accounts |
| 015 | `items` Amharic fields | name_am / description_am |
| 016 | `sg_staff` | SG staff accounts with fixed staff_role |
| 017 | `sos_alerts` | Emergency/SOS button backend |
| 018 | `role_permissions`, `users.staff_role` | Admin capability system |
| 019 | EtelGroup-managed flag | Cross-system staff account flag |
| 020–022 | Zone coordinate columns, zone relocation | Migrated zone model to Hawassa |
| 023 | `customer_favorites`, `customer_addresses`, `customer_messages`, `customer_referral_rewards`, `etelpay_user_overrides` | Customer features |
| 024 | `ride_favorite_routes`, referral `paid_at` | Saved ride routes |
| 025–026, 029, 032 | `rides.vehicle_type`, `rides.surge_applied`, `rides.fare_breakdown` JSON, `rides.last_location_at` | Ride table extensions |
| 028 | `geocode_cache` | Cached lat/lng lookups |
| 030 | `ride_path_points` | GPS breadcrumb trail per ride |
| 031 | `driver_vehicle_change_requests` | Admin-approved vehicle change workflow |
| 033 | Ride ratings/sharing/scheduling columns | Share links, scheduled rides |
| 034 | Driver commission tracking columns | Added to `ride_drivers` |
| 035 | Launch checklist state | Admin pre-launch checklist |
| 036 | `equity_round_settings`, `equity_investors`, `equity_profit_distributions`, `equity_profit_distribution_items` | Founder/investor cap table |
| 037 | `driver_shifts`, `platform_cost_assumptions` | Shift tracking + cost model inputs |
| 038 | `driver_fuel_logs` | Driver fuel-cost tracking |
| 039 | Investor EtelID login | Investor SSO |
| 040–042 | `equb_groups`, `equb_members`, `equb_contributions`, `equb_payouts`, `equb_participants`, `equb_packages` | Equb rotating-savings subsystem |
| 043–044 | `courier_shifts`, `courier_fuel_logs` | Courier operational tracking |
| 045 | `business_hires_plan`, `business_plan_notes` | Admin hiring-plan tool |
| 046 | Hex-grid geospatial matching columns | Ride dispatch matching (`api/lib/hexgrid.php`) |
| 047 | `growth_goal_assumptions` | Growth-planner inputs |
| 048 | Founder capital tracking | Founder capital contributions |
| 049 | `sg_roles` | SG custom staff roles |
| 050 | `telebirr_payments` redefinition | Schema correction |
| 051–055 | `sg_bank_account`, `sg_payout_methods`, `sg_payout_change_requests`, payment_method_logos, payout holder names | SG payout/banking subsystem |
| 056 | `admin_documents`, `admin_document_versions` | Admin internal document library |
| 057 | NFC/EtelID link | Links NFC card taps to EtelID identities |

## 3. Tables created inline by controller code (not in migrations/ or seeds/)

| Table | Created in | Key columns | Purpose |
|---|---|---|---|
| `rides` | `RideController.php` (~line 57) | passenger_id, driver_id, pickup/dropoff lat/lng+address, distance_km, fare_estimate/final/paid, payment_method, `status ENUM('searching','accepted','in_progress','completed','cancelled')`, rating/rating_comment, expires_at/assigned_at/started_at/completed_at/cancelled_at | Core ride entity |
| `ride_drivers` | `RideController.php` (~line 145) | user_id (PK), online, lat/lng, vehicle_plate/type/make/color/year, license_number/name/dob, `identity_match ENUM('unverified','matched','mismatch')`, selfie_url, license_photo_url, `onboarded` flag, priority_score, total_earnings/paid_out/rides, rating_sum/count, last_seen, suspension columns | Driver profile & onboarding gate |
| `driver_payouts` | `RideController.php` (~2648) | user_id, amount, partner_ref (unique), tx_ref, status | Driver cash-out records |
| `driver_etel_money_topups` | `RideController.php` / `AdminController.php` | user_id, amount, tx_ref (unique), source, status, note, receipt_image_url, approved_by/at | Two-step-gated Etel Money top-up |
| `order_issues` | `AdminController.php` / `OrderController.php` | order_id, reporter_id, category, details, status, resolved_at | Order dispute tracking |
| `driver_compliance_requests` | `RideController.php` (~353) | driver_user_id, `doc_type ENUM('insurance','technical_inspection','road_fund')`, requested_expiry_date, requested_receipt_url, status, reject_reason, reviewed_at/by | Compliance document workflow |
| `driver_goal_tiers` | `AdminController.php` | id, trips_required, bonus_etb, active, sort_order | Driver incentive tiers |
| `app_release_channels` / `app_canary_testers` | `api/lib/app_releases.php` | per-app (driver/ride/customer/courier/servicegiver/admin) version + canary allowlist | Staged rollout |
| `system_reset_tokens` | `SystemResetController.php` | confirmation-token gate | Danger-zone execute confirmation |
| `ride_messages` / `ride_typing` | `RideController.php` | ride_id, sender, message/typing state | In-ride chat |

## 4. Notable design distinction

There is **no standalone `drivers` table**. Delivery-app couriers
(`couriers`) and ride-app drivers (`ride_drivers`) are two entirely separate
tables/roles, even though the same `users.id` could in principle hold either.
This must be preserved in any future schema refactor — merging them would
break the two products' independent onboarding and status models.
