# 04 — Module Breakdown

## Backend (`delivery/api/`)

| Path | Role |
|---|---|
| `boot.php` | Single dispatch entrypoint, auth, rate limiting, 31 inline actions |
| `controllers/AuthController.php` | Identity & session (6 actions) |
| `controllers/AdminController.php` | Platform administration (73 actions) |
| `controllers/OrderController.php` | Delivery order lifecycle (47 actions) |
| `controllers/RideController.php` | Ride-hailing lifecycle (65 actions, ~210KB, largest module) |
| `controllers/ServiceGiverController.php` | Storefront operations (28 actions) |
| `controllers/EquityController.php` | Investor cap table & distributions (18 actions) |
| `controllers/EqubController.php` | Rotating savings (19 actions) |
| `controllers/PlanningController.php` | Business/hiring plan (7 actions) |
| `controllers/PlatformEconomicsController.php` | Cost/growth assumptions (6 actions) |
| `controllers/AgentController.php` | EtelAI machine-to-machine booking (9 actions) |
| `controllers/NfcController.php` | EtelID NFC-tap bridge (5 actions) |
| `controllers/DocumentsController.php` | Internal document library (7 actions + 2 standalone endpoints) |
| `controllers/SystemResetController.php` | Danger-zone data wipe (3 actions) |
| `controllers/DriverFuelController.php` / `CourierFuelController.php` | Fuel logs (4 actions each) |
| `controllers/PushController.php` | Web Push subscriptions (3 actions) |
| `controllers/InvestorPortalController.php` | Legacy token-link investor portal (2 actions) |
| `lib/delivery_pricing.php` | Delivery fare calculation |
| `lib/ride_fare.php` | Ride fare calculation (shared by RideController + AgentController) |
| `lib/hexgrid.php` | Geospatial hex-grid driver matching |
| `lib/schema_helpers.php` | Idempotent runtime schema healing (`rides_add_missing_cols()`) |
| `lib/validate.php` | Centralized input validation (phone, amount, etc.) |
| `lib/app_releases.php` | Staged release-channel/canary management |
| `etelid_auth.php` | EtelID SSO cookie-session bridge (the one cookie-based auth surface) |
| `telegram_webhook.php` | Telegram bot integration for operational alerts |
| `documents_upload.php` / `documents_download.php` | Standalone multipart endpoints outside the action-dispatch pattern |
| `updater.php` / `updater-api.php` | Production file-deploy tool |
| `migrate.php` | Migration runner |
| `migrations/001-057_*.sql` | Versioned schema changes |
| `seeds/complete_migration.sql` | Fresh-install schema baseline (19 core tables) |

## Frontend (`delivery/`)

| App | Entry point(s) | Role served |
|---|---|---|
| Customer/Delivery | `customer.html` (canonical, confirmed) — `index.html` is legacy/deprecated | Customer |
| Ride (passenger) | `ride/index.html`, `ride/share.html` | Customer/passenger |
| Driver | `driver/index.html` | Driver |
| Courier | `courier/index.html`, `courier/courier-index.html` — **still unresolved**: both files carry the same recent modification timestamp with no clear signal of which is live; confirm which is linked from production navigation/login before deprecating either | Courier |
| Service Giver | `servicegiver.html`, `admin_servicegiver_extension.html` | Service Giver |
| Admin | `admin.html` | Admin |
| Equb | `equb/index.html` | Driver/Courier (benefit feature) |
| Public tracking | `track.html` | Unauthenticated |
| Offline fallback | `offline.html` | All (service worker navigation fallback) |

Each of the 6 installable apps (`driver`, `ride`, `customer`, `courier`,
`servicegiver`, `admin`) has its own manifest, is independently versioned,
and is packaged as an Android Trusted Web Activity (TWA) for installable
distribution outside the browser.

## Admin front-end module breakdown (`admin.html`, 21 nav pages)

| Nav page | Icon | Backing controller |
|---|---|---|
| Dashboard | 📊 | AdminController (dashboard stats) |
| Orders | 📦 | OrderController / AdminController |
| Users | 👥 | AdminController |
| Couriers | 🚗 | AdminController |
| Service Givers | 🏪 | AdminController |
| Items | 🛍️ | AdminController |
| Rides | 🚖 | RideController (admin actions) |
| Pricing | 💰 | AdminController (pricing_rules, ride_fare_rules) |
| Payments (Telebirr) | 💳 | OrderController (Telebirr/bank review) |
| Reports | 📈 | AdminController / OrderController / ServiceGiverController |
| Updater | ⬆️ | `updater.php` / `updater-api.php` |
| Support | 🎧 | AdminController (order/ride issue resolution, SOS) |
| Launch | 🚀 | AdminController (launch checklist) |
| Releases | 🐤 | `lib/app_releases.php` (canary/stable) |
| Settings | ⚙️ | AdminController |
| Branding | 🎨 | AdminController |
| Roles | 🔐 | AdminController (`role_permissions` CRUD) |
| Finance & Planning | 💼 | EquityController + PlatformEconomicsController + PlanningController (5 sub-tabs) |
| Equb | 🤝 | EqubController |
| Danger Zone | ☠️ | SystemResetController |
| Documents | 📄 | DocumentsController |

## Build pipeline

`js/build-bundles.js` (terser, `compress:false, mangle:{toplevel:false}`)
compiles per-app source files into minified `-bundle.js` files, which are
then synced into versioned `js/releases/{app}/{version}/` folders managed
by the release-channel system above. Source edits alone do not change
production behavior until this rebuild-and-promote step completes.
