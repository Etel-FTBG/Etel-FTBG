# 02 — API Contracts (Ride-relevant)

## Dispatch model

Single entrypoint: `api/boot.php`, shared with Etel Delivery. Every request
carries an `action` field, dispatched to one of 17 controller files. Only
Ride-relevant controllers/actions are detailed below.

## Ride-relevant controller inventory

| Controller | Actions in scope | Domain |
|---|---|---|
| `AuthController.php` | register, login, etelid_login, admin_etelid_login, change_password (5 of 6 — sg_login is Delivery-only) | Identity & session (shared) |
| `RideController.php` | 65 actions | Ride-hailing lifecycle (fully in scope) |
| `AdminController.php` | Ride fare/pricing config, ride/driver issue resolution, driver account management (subset of 73 total actions) | Platform administration |
| `EqubController.php` | 19 actions | Rotating savings (shared with couriers) |
| `AgentController.php` | agent_ride_quote, agent_book_ride, agent_ride_status, agent_cancel_ride (4 of 9 — the rest are Delivery-only) | EtelAI machine-to-machine booking |
| `NfcController.php` | nfc_start_ride (1 of 5 — the rest are Delivery-only) | EtelID NFC-tap bridge |
| `DriverFuelController.php` | 4 actions | Driver fuel logs |
| `PushController.php` | 3 actions | Web Push subscriptions (shared) |

Out of scope (Delivery-only, not detailed here): `OrderController.php`,
`ServiceGiverController.php`, `CourierFuelController.php`, and the
Delivery-facing actions within `AdminController.php`, `AgentController.php`,
and `NfcController.php`.

## Authentication schemes in use (shared with Delivery)

1. **Bearer token** (most user-facing actions) — `Authorization: Bearer <token>`.
   Token = base64(`user_id:issued_at:token_version:hmac`), HMAC-SHA256 signed
   with `TOKEN_SECRET_FINAL`. 7-day hard expiry. `get_auth_user()` additionally
   compares the embedded `token_version` against the live `users.token_version`
   column for immediate revocation.
2. **Shared service key** (`AgentController`, `NfcController`) — `hash_equals()`
   constant-time check against `ETELID_SERVICE_KEY`, sent as a header with a
   `?key=` query-param fallback.

## Worked request/response examples

### `login`
```
POST /api/boot.php
{ "action": "login", "phone": "0912345678", "password": "••••••••" }

→ 200 OK
{ "success": true, "token": "<bearer token>", "user": { "id": 123, "name": "...", "role": "customer", ... } }
```

### `book_ride`
```
POST /api/boot.php   Authorization: Bearer <token>
{
  "action": "book_ride",
  "vehicle_type": "car",
  "pickup_lat": 7.06, "pickup_lng": 38.47, "pickup_address": "...",
  "dropoff_lat": 7.08, "dropoff_lng": 38.49, "dropoff_address": "...",
  "payment_method": "cash",
  "quote_token": "<from ride_estimate_fare>"
}

→ 200 OK
{ "success": true, "ride": { "id": 3301, "status": "searching", "fare_estimate": 85.00, "expires_at": "..." } }
```

### `driver_topup_etel_money`
```
POST /api/boot.php   Authorization: Bearer <token>   (role=driver, onboarded=1 required)
{ "action": "driver_topup_etel_money", "amount": 500.00, "tx_ref": "EP-...", "receipt_image_url": "..." }

→ 200 OK
{ "success": true, "topup": { "id": 771, "status": "pending", "amount": 500.00 } }
```
Note: the balance is **not** credited on this response — `tx_ref` is
server-verified via `etel_pay_verify_tx()` before the row is even created as
`pending`, and a separate admin action (`admin_approve_etel_topup`) must
approve it before `ride_drivers.total_earnings`/wallet balance actually moves.

## Real-time / streaming interfaces

| Endpoint | Transport | Purpose |
|---|---|---|
| `sse_ride_status` | Server-Sent Events | Live ride status push to passenger/driver |
| `sse_driver_stream` | Server-Sent Events | Live driver location push |

## External interface contracts (Ride-relevant)

| System | Actions/files | Auth |
|---|---|---|
| EtelID SSO | `etelid_login`, `admin_etelid_login` | User-driven redirect flow |
| EtelID NFC bridge (ride) | `NfcController.php::nfc_start_ride` | Shared service key |
| EtelPay | `etel_pay_verify_tx()` call site in `RideController.php` | Server-to-server verification call |
| Telegram | `api/telegram_webhook.php` | Bot token |
