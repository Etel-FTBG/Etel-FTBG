# 01 — Database Schema (Ride-relevant)

Etel Ride and Etel Delivery share one MySQL database and one schema-migration
history (`api/migrations/001-057_*.sql`, plus `api/seeds/complete_migration.sql`
for fresh installs). Only Ride-relevant tables are described below.
Delivery-only tables (`orders`, `order_items`, `items`, `service_givers`,
`delivery_zones`, `couriers`, etc.) are out of scope for this document.

## 1. Shared core tables (used by Ride)

| Table | Key columns | Purpose |
|---|---|---|
| `users` | id, name, phone (unique), email, password_hash, `role`, lang, active, timestamps | Shared identity table. `role` distinguishes passenger (`customer`), `driver`, `admin`. Also used by Delivery for `courier`/`service_giver` roles — out of scope here. |
| `role_permissions` | role_name, capabilities (TEXT) | Admin capability system, shared with Delivery |

## 2. Ride-specific tables added by numbered migrations

| Migration | Table/change | Purpose |
|---|---|---|
| 001 | `login_attempts` | Brute-force/rate-limit tracking (shared with Delivery) |
| 006 | `users.token_version` | Bearer-token revocation counter (shared) |
| 007 | `ride_fare_rules` | Per-vehicle-type fare config (base_fare, per_km_rate, wait_rate_per_min, min_fare) |
| 009 | `driver_announcements`, `driver_announcement_reads` | Admin-authored driver news + read tracking |
| 010 | `ride_issues` | Passenger/driver-reported ride problems |
| 017 | `sos_alerts` | Emergency/SOS button backend (shared field for ride_id, reporter role) |
| 024 | `ride_favorite_routes` | Saved ride routes + referral `paid_at` |
| 025 | `rides.vehicle_type` | Ride table extension |
| 026 | `rides.surge_applied` | Ride table extension |
| 028 | `geocode_cache` | Cached lat/lng lookups |
| 029 | `rides.fare_breakdown` JSON | Ride table extension |
| 030 | `ride_path_points` | GPS breadcrumb trail per ride |
| 031 | `driver_vehicle_change_requests` | Admin-approved vehicle change workflow |
| 032 | `rides.last_location_at` | Ride table extension |
| 033 | Ride ratings/sharing/scheduling columns | Share links, scheduled rides |
| 034 | Driver commission tracking columns | Added to `ride_drivers` |
| 037 | `driver_shifts` | Shift tracking |
| 038 | `driver_fuel_logs` | Driver fuel-cost tracking |
| 040–042 | `equb_groups`, `equb_members`, `equb_contributions`, `equb_payouts`, `equb_participants`, `equb_packages` | Equb rotating-savings subsystem (shared with couriers, out of scope) |
| 046 | Hex-grid geospatial matching columns | Ride dispatch matching (`api/lib/hexgrid.php`) |

## 3. Tables created inline by RideController.php (not in migrations/)

| Table | Key columns | Purpose |
|---|---|---|
| `rides` | passenger_id, driver_id, pickup/dropoff lat/lng+address, distance_km, fare_estimate/final/paid, payment_method, `status ENUM('searching','accepted','in_progress','completed','cancelled')`, rating/rating_comment, expires_at/assigned_at/started_at/completed_at/cancelled_at | Core ride entity |
| `ride_drivers` | user_id (PK), online, lat/lng, vehicle_plate/type/make/color/year, license_number/name/dob, `identity_match ENUM('unverified','matched','mismatch')`, selfie_url, license_photo_url, `onboarded` flag, priority_score, total_earnings/paid_out/rides, rating_sum/count, last_seen, suspension columns | Driver profile & onboarding gate |
| `driver_payouts` | user_id, amount, partner_ref (unique), tx_ref, status | Driver cash-out records |
| `driver_etel_money_topups` | user_id, amount, tx_ref (unique), source, status, note, receipt_image_url, approved_by/at | Two-step-gated Etel Money top-up |
| `driver_compliance_requests` | driver_user_id, `doc_type ENUM('insurance','technical_inspection','road_fund')`, requested_expiry_date, requested_receipt_url, status, reject_reason, reviewed_at/by | Compliance document workflow |
| `driver_goal_tiers` | id, trips_required, bonus_etb, active, sort_order | Driver incentive tiers |
| `ride_messages` / `ride_typing` | ride_id, sender, message/typing state | In-ride chat |

Also created inline, shared with Delivery (out of scope here): `app_release_channels`
/ `app_canary_testers` (staged rollout, used by every app including Ride/Driver),
`order_issues` (Delivery only).

## 4. Notable design distinction

There is **no standalone `drivers` table shared with Delivery's courier concept**.
`ride_drivers` (this document's scope) and `couriers` (Delivery, out of scope) are
two entirely separate tables/roles, even though the same `users.id` could in
principle hold either.
