# 04 — Module Breakdown (Ride-relevant)

## Backend (`delivery/api/`) — Ride-relevant files

| Path | Role |
|---|---|
| `boot.php` | Single dispatch entrypoint, auth, rate limiting — shared with Delivery |
| `controllers/AuthController.php` | Identity & session — shared with Delivery |
| `controllers/RideController.php` | Ride-hailing lifecycle (65 actions, ~210KB, largest module in the codebase) |
| `controllers/AdminController.php` | Platform administration — only its ride fare/pricing and ride/driver-issue-resolution actions are in scope; its order/zone/service-giver actions are Delivery-only |
| `controllers/EqubController.php` | Rotating savings (19 actions, shared with couriers) |
| `controllers/AgentController.php` | EtelAI machine-to-machine booking — only its ride_* actions are in scope |
| `controllers/NfcController.php` | EtelID NFC-tap bridge — only nfc_start_ride is in scope |
| `controllers/DriverFuelController.php` | Fuel logs (4 actions) |
| `controllers/PushController.php` | Web Push subscriptions (3 actions, shared) |
| `lib/ride_fare.php` | Ride fare calculation (shared by RideController + AgentController) |
| `lib/hexgrid.php` | Geospatial hex-grid driver matching |
| `lib/schema_helpers.php` | Idempotent runtime schema healing (`rides_add_missing_cols()`) |
| `lib/app_releases.php` | Staged release-channel/canary management, shared across all apps |
| `etelid_auth.php` | EtelID SSO cookie-session bridge (shared) |
| `telegram_webhook.php` | Telegram bot integration for operational alerts (shared) |
| `updater.php` / `updater-api.php` | Production file-deploy tool (shared) |
| `migrate.php` | Migration runner (shared) |

Out of scope (Delivery-only): `controllers/OrderController.php`,
`controllers/ServiceGiverController.php`, `controllers/CourierFuelController.php`,
`lib/delivery_pricing.php`.

## Frontend (`delivery/`) — Ride-relevant apps

| App | Entry point(s) | Role served |
|---|---|---|
| Ride (passenger) | `ride/index.html`, `ride/share.html` | Passenger |
| Driver | `driver/index.html` | Driver |
| Equb | `equb/index.html` | Driver (benefit feature, shared with couriers) |
| Offline fallback | `offline.html` | All (service worker navigation fallback) |

Each installable app has its own manifest, is independently versioned, and is
packaged as an Android Trusted Web Activity (TWA).

Out of scope (Delivery-only): `customer.html`/`index.html`, `courier/`,
`servicegiver.html`, `track.html`. Note: `admin.html` and `login.html` are
shared entry points used by every role including Ride/Driver — they are not
themselves Delivery- or Ride-exclusive.

## Ride-relevant admin front-end areas (within the shared `admin.html`)

| Nav page | Backing controller |
|---|---|
| Rides | RideController (admin actions) |
| Pricing | AdminController (`ride_fare_rules` subset) |
| Support | AdminController (ride/driver issue resolution, SOS) |
| Releases | `lib/app_releases.php` (Ride/Driver channels) |
| Equb | EqubController |

`admin.html` also has Delivery-only nav pages (Orders, Couriers, Service
Givers, delivery Pricing) and platform-wide pages unrelated to either service
line (Roles, Finance & Planning, Danger Zone, Documents) — out of scope here.

## Build pipeline (shared)

`js/build-bundles.js` (terser) compiles per-app source files into minified
`-bundle.js` files, synced into versioned `js/releases/{app}/{version}/`
folders managed by the release-channel system. Source edits alone do not
change production behavior until this rebuild-and-promote step completes.
