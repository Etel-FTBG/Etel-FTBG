# 03 — State Machines (Ride-relevant)

## 3.1 Ride Lifecycle (`rides.status`)

DB enum: `ENUM('searching','accepted','in_progress','completed','cancelled')`

```
        book_ride
            │
            ▼
       ┌─────────┐   no driver accepts before expires_at   ┌───────────┐
       │searching│ ─────────────────────────────────────► │ cancelled │
       └────┬────┘                                          └───────────┘
            │ driver_accept_ride
            ▼
       ┌─────────┐   driver_cancel_ride / cancel_ride
       │accepted │ ─────────────────────────────────────► │ cancelled │
       └────┬────┘
            │ driver_arrived (see note below)
            │ + driver_start_ride
            ▼
       ┌────────────┐   driver_cancel_ride / cancel_ride
       │in_progress │ ─────────────────────────────────────► │ cancelled │
       └─────┬──────┘
             │ driver_complete_ride
             ▼
       ┌───────────┐
       │ completed │
       └───────────┘
```

**Note on "arrived":** `arrived` is not a value in the `rides.status` enum.
Based on the `driver_arrived` / `customer_confirm_arrival` action pair in
`RideController.php`, it is represented as a sub-state signalled by a
timestamp/flag alongside `status='accepted'` (e.g. a `driver_arrived_at`
column or equivalent), rather than a 6th enum value — **worth confirming
precisely against the live `driver_arrived` handler before this diagram is
treated as exhaustive for the audit.**

Waiting-fee accrual (`wait_active` / `wait_started_at` / `wait_seconds_total`
in `api/lib/ride_fare.php`) begins once the driver has arrived and is
waiting for the passenger, independent of the status enum.

## 3.2 Driver Onboarding Gate

```
  register / etelid_login  →  users.role = 'customer' (always, regardless of intent)
                                        │
                            driver_update_profile (submit vehicle info,
                            selfie, license — NOT gated, deliberately open
                            so onboarding can begin)
                                        │
                                        ▼
                          ride_drivers row created, onboarded = 0
                                        │
                     EtelID identity cross-check + admin/system review
                                        │
                                        ▼
                          ride_drivers.onboarded = 1
                          users.role updated to 'driver'
                                        │
                                        ▼
        rides_require_onboarded() now passes — the following unlock:
        driver_go_online, driver_get_nearby_requests, driver_accept_ride,
        driver_hail_customer, driver_start_ride, driver_arrived,
        driver_complete_ride, driver_cashout, driver_topup_etel_money
```

This single shared gate function (`rides_require_onboarded()`) was
introduced to close a fraud/safety gap: previously, any authenticated
role — including a plain, non-onboarded `customer` — could call these
driver-privileged actions with no onboarding check at all.

## 3.3 Etel Money Top-up (two-step approval)

```
  driver_topup_etel_money (driver submits tx_ref + receipt)
              │
              ▼
  etel_pay_verify_tx()  ──fails──►  rejected, no row created
              │ succeeds
              ▼
  driver_etel_money_topups row created, status = 'pending'
              │
              ▼
  admin_approve_etel_topup (admin, separate step)
              │
              ▼
  status = 'approved'  →  balance credited to ride_drivers.total_earnings/wallet
```

## 3.4 Compliance Document / Vehicle Change Approval (shared pattern)

```
  driver submits (driver_submit_compliance_document /
                   RideController vehicle-change action)
              │
              ▼
        status = 'pending'
              │
     ┌────────┴────────┐
     ▼                  ▼
  admin_approve_*   admin_reject_*
     │                  │
     ▼                  ▼
 status='approved'  status='rejected' + reject_reason
 (only approval point where ride_drivers is actually updated —
  this is what makes approval apply everywhere: map markers, ride
  previews, driver profile — instantly, with no separate propagation
  logic needed)
```
