# Technical Design Document / Low-Level Design (TDD/LLD)
## Etel Ride Platform — v1.0

Prepared for the INSA cyber-security audit application referenced in Etel Group's
permission request letter to INSA's Director General, submitted in support of a
Road Transport license application with the Ministry of Transport and Logistics.
Companion to the SRS and SDD documents.

## Scope note

Etel Ride shares one backend and one database with Etel Delivery (Etel Group's
parcel/food delivery service line) — there is no separate deployment. This
document describes only the Ride-facing schema, API surface, and modules.
Where a shared component (authentication, the admin capability system, hosting)
also serves Delivery, that is stated explicitly rather than hidden; Delivery-only
components (orders, items, service givers, couriers) are out of scope and are
not detailed here.

## Contents

1. `01_Database_Schema.md` — Ride-relevant table inventory
2. `02_API_Contracts.md` — Ride-relevant controller/action inventory
3. `03_State_Machines.md` — ride and driver-onboarding lifecycle state machines
4. `04_Module_Breakdown.md` — file-level module map (Ride-relevant)
5. `05_Security_Controls.md` — implementation-level security mechanisms

All content in this package is derived directly from the production source code
at `/delivery/` in the Etel-FTBG repository, cross-verified against the
project's internal security review. No content here is speculative — every
claim is traceable to a specific file, table, or action name in the codebase.
