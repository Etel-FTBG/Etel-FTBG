# 05 — Security Controls (Implementation Level, Ride-relevant)

This section documents concrete implementation-level security controls as
they apply to Etel Ride. Most of these mechanisms (authentication, injection
prevention, rate limiting) are shared infrastructure also used by Etel
Delivery — they are described here because Ride depends on them, not because
they are Ride-exclusive.

## 1. Authentication (shared)

- Custom signed bearer-token scheme (`api/boot.php`), not PHP sessions, not JWT.
- `gen_token($user_id, $version)`: packs `user_id:issued_at:token_version`,
  HMAC-SHA256-signs with `TOKEN_SECRET_FINAL`, base64-encodes.
- `verify_token()`: hard 7-day lifetime; malformed tokens rejected closed;
  signature compared with timing-safe `hash_equals()`.
- `get_auth_user()`: additionally compares the token's embedded
  `token_version` against the live `users.token_version` column — a
  mismatch invalidates the token immediately, independent of the 7-day
  window. This is the server-side revocation mechanism.
- No silent token refresh exists anywhere — expiry always produces a clean
  401 requiring re-login.
- `logout` calls a helper that increments `token_version`, invalidating
  every outstanding token for that user across every device in one write.
- Exactly one cookie-based auth surface exists in the whole codebase:
  `api/etelid_auth.php` (bridging to EtelID's SSO), using
  `Secure` (conditional on real HTTPS detection) + `HttpOnly` +
  `SameSite=Lax` + an 8-hour inactivity timeout.
- Service-to-service auth (`AgentController`'s ride actions, `NfcController`'s
  `nfc_start_ride`) uses a separate shared-secret scheme
  (`ETELID_SERVICE_KEY`, `hash_equals()`), independent of the bearer-token
  system, with a `?key=` query-param fallback alongside the header.

## 2. Authorization (Ride-specific)

- Driver onboarding gate: `rides_require_onboarded()` — a single shared
  function gating every driver-privileged ride action on
  `ride_drivers.onboarded = 1`, closing a fraud/safety gap where any
  authenticated role could otherwise accept and run a real ride.
- Ownership checks: ride-scoped actions verify the caller's own
  passenger_id/driver_id matches the ride being acted on; shared/two-party
  actions (e.g. `send_ride_message`) compute the caller's role from
  whichever column matches and reject with 403 if neither does.
- `nfc_start_ride` independently re-verifies the resolved driver's
  onboarding status server-side, so the NFC path cannot be used to route
  around the same gate the phone-entry ride flow enforces.
- Admin capability model (shared): ride-relevant admin actions are gated
  through `require_admin($pdo, 'capability')`, checking both the `admin`
  role and a specific capability string (e.g. `pricing.manage`) against the
  `role_permissions` table.

## 3. Injection Prevention (shared)

- All database access uses PDO parameterized queries with
  `PDO::ATTR_EMULATE_PREPARES => false`.
- Any dynamic column/table name always traces to a hardcoded whitelist,
  never to request input; `LIMIT`/date-range values are always
  `intval()`'d or selected from fixed fragments.

## 4. Output Encoding (XSS Prevention) — Ride-facing surfaces

- All user-controllable values rendered via `innerHTML` or equivalent in
  `driver.js`/`ride.js` are passed through `escapeHtml()`/`esc()` helpers
  (shared helpers defined in `js/core.js`).
- Stored-XSS sinks in ride-history detail modals (`driver.js`, `ride.js`)
  were found and fixed during the codebase's internal security review.
- `escUrl()` helper rejects `javascript:` / `vbscript:` / `data:text/html`
  schemes on any raw image/photo URL placed into an attribute (applied to
  `driver.js`/`ride.js` among other app files).
- Fixes are propagated into the versioned release bundles
  (`js/releases/{app}/{version}/`), not just source.

## 5. File Upload Handling (Ride-relevant: driver documents)

- `upload.php`: content-sniffed MIME-type whitelist (not filename
  extension alone), size cap, whitelisted destination folders, fully
  server-generated filenames (client filename never used) — used for
  driver selfie, license photo, and compliance-document uploads.

## 6. Rate Limiting (shared)

- `login_attempts` table + `rate_limit_check()` / `rate_limit_fail()` /
  `rate_limit_clear()` helpers in `boot.php`, applied to `login`, keyed by
  `login:<phone>`.

## 7. Error Handling & Logging (shared, spot-checked on Ride-relevant files)

- `change_password`'s token-refetch failure hard-fails
  (`require_relogin: true`) rather than soft-degrading with a possibly
  stale token — applies to driver and passenger accounts alike.

## 8. Web-Server-Level Controls (shared)

- `Options -Indexes` set repo-wide; `api/backups/` (runtime deploy backups
  created by the Updater tool) has its own explicit `Require all denied`
  `.htaccess`.
- Updater tool credentials load from `.env`/`getenv()` and fail closed
  (HTTP 503) if unset — no default password, no silent bypass.

## 9. Payment Integrity (Ride-relevant: driver earnings)

- Driver Etel Money top-ups: `tx_ref` is server-verified via
  `etel_pay_verify_tx()` against EtelPay before the top-up row is even
  created as `pending`; balance only moves after a **second**, independent
  admin approval step (`admin_approve_etel_topup`) — a single compromised
  or spoofed `tx_ref` cannot move funds without both checks passing.
