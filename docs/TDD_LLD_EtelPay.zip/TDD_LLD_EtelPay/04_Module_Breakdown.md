# 04 — Module Breakdown

## Backend (`Etel.Pay/wallet/api/`)

| Path | Role |
|---|---|
| `v2_verify.php` | Single dispatch entrypoint: request parsing, auth (bearer token or service key), database connection, routing into `ep_r1`/`ep_r2`/`ep_r3`. Deliberately not named `api.php`, and kept under this host's file-size WAF-deletion threshold, per known hosting constraints for this system. |
| `ep_r1.php` | Auth/session, wallet balance/history/rates, P2P send, escrow, service-to-service transaction verification and partner credit/platform transfer, QR generate/process, Telegram OTP relay, diagnostics (832 lines, ~19 actions) |
| `ep_r2.php` | Profile/avatar, PIN change, top-up initiate/confirm, and the majority of admin actions — users, transactions, rates, settings (460 lines, ~23 actions) |
| `ep_r3.php` | Payment links, API-key self-service, KYC, analytics, disputes, EtelID SSO/KYC bridge, and `_ep_require_admin()` (453 lines, ~19 actions) |
| `etelid_kyc.php` | Outbound bridge to EtelID for KYC identity cross-checking; guards direct access and verifies TLS on outbound calls |
| `etelid_member_detail.php` | Standalone, service-key-authenticated single-member lookup for EtelID's Members Controller |
| `etelid_members_list.php` | Standalone, service-key-authenticated member list for EtelID's Members Controller; a debug-fingerprint response leaking part of the real service key was removed from its error path during the security review |
| `service_check_wallet.php` | Standalone, service-key-authenticated wallet-status check that deliberately excludes balance fields |
| `service_nfc_charge.php` | Standalone, service-key-authenticated NFC tap-to-pay charge |
| `updater-api.php` | EtelPay's own production file-deploy and raw-SQL tool, own password + signed-token auth scheme (fixed during the security review to reject the shipped placeholder password) |

## Frontend (`Etel.Pay/wallet/`)

| Page | Role served |
|---|---|
| `login.html` | Sign-in (phone+PIN or EtelID SSO) |
| `register.html` | Removed during the security review's second pass — its form posted to a non-existent backend action (`etel_pay_register_wallet`); registration remains EtelID-SSO-only |
| `wallet.html` | Main dashboard/balance |
| `send.html` | P2P transfer |
| `pay.html` / `pay-links.html` | QR/payment-link payments |
| `qr.html` | QR generation/scan |
| `topup.html` | Top-up flow |
| `history.html` | Transaction history |
| `profile.html` | Profile/avatar |
| `kyc.html` | KYC document submission |
| `admin.html` | Admin panel (users, transactions, rates, settings, disputes, KYC, top-ups, analytics) |
| `analytics.html` | Analytics dashboard |
| `updater.html` | Deploy tool UI, password-gated, separate from the main wallet login |
| `diag.html` | Developer diagnostics console, not in normal nav — its raw JSON dump into `innerHTML` was given an escaping helper during the security review's second pass |
| `offline.html` | PWA offline fallback |
| `manifest.json` / `manifest.php`, `sw.js` | PWA manifest and service worker |

Supporting JS: `js/core.js` (shared helpers incl. the `EP_CORE.esc()` escaper
used consistently across every page that renders another user's free text),
`js/api.js`, `js/config.js`, `js/desktop.js`/`desktop-shell.js`,
`js/devpanel.js`, `js/logo-anim.js`.

## Build/Deploy Pipeline

EtelPay has no separate build/bundling step and no versioned release-channel
system, unlike Delivery & Ride's terser-bundle-and-canary-channel pipeline —
source files are deployed as-is via `updater.html`/`updater-api.php`, with a
runtime backup of every replaced file written to `backups/` (now protected by
its own `.htaccess`, added during the security review after 222 pre-existing
backup files were found web-accessible with no protection at all).
