# 02 — API Contracts

## Dispatch model

Single entrypoint: `api/v2_verify.php`. The action name is read from
`$body['action']` (POST JSON body), falling back to `$body['ep_action']`, then
`$_GET['action']`. Dispatch tries `ep_route_part1($action)`, then
`ep_route_part2($action)`, then `ep_route_part3($action)` in order, each
returning `false` to fall through if the action isn't its own — a 404
`'Unknown action'` results only if none of the three claim it. Four additional
standalone scripts are called directly by URL, bypassing this router entirely,
and `updater-api.php` is a wholly separate router with its own auth scheme.

## Route-handler inventory (~66 actions total)

| File | Actions in scope | Domain |
|---|---|---|
| `ep_r1.php` | 19 actions | Auth/session, wallet balance/history/rates, P2P send, escrow, QR, Telegram OTP relay, diagnostics |
| `ep_r2.php` | 23 actions | Profile/avatar, PIN change, top-up, and the bulk of admin actions |
| `ep_r3.php` | 19 actions | Payment links, API keys, KYC, analytics, disputes, EtelID SSO/KYC bridge |
| 4 standalone scripts | 1 action each | Cross-system read-only lookups + NFC charge |
| `updater-api.php` | 13 actions | Production file-deploy tool, own auth scheme |

## Authentication schemes in use

1. **Bearer token** (most user-facing actions) — `Authorization: Bearer
   <token>`. Token = `bin2hex(openssl_random_pseudo_bytes(32))`, a genuinely
   random 256-bit value with no embedded, self-verifiable data — stored
   server-side in `ep_sessions`. `ep_auth()` validates by joining
   `ep_sessions` to `ep_users` on the exact token string, requiring
   `expires_at > NOW()` (7-day hard cap) and, as of this review,
   `last_active_at` within the last 8 hours (idle timeout), refreshing
   `last_active_at` on every successful call. Also re-checks
   `status = 'active'` on every request, not only at login.
2. **Shared service key** (`X-Etel-Key` for `ep_r1.php`'s money-moving
   service actions, `X-Etel-Service-Key` for the four standalone scripts) —
   `hash_equals()` constant-time comparison, sent as a header with a `?key=`
   query-param fallback for hosts that strip custom headers. Money-moving
   actions compare against `EP_SECRET_FINAL` (a safe, auto-derived fallback
   used whenever the raw `EP_SECRET` config value is still the shipped
   placeholder), not the raw `EP_SECRET` constant directly.
3. **Updater password + signed token** (`updater-api.php` only) — a single
   shared password (`EP_UPDATER_PASS`), checked by
   `upd_password_is_configured()` (fixed during the security review to
   lower-case and trim before comparing, closing a case-sensitivity gap that
   let the shipped placeholder through as "configured"), gates `login`; every
   other action requires the resulting signed token.

## Worked request/response examples

### `ep_login`
```
POST /api/v2_verify.php
{ "action": "ep_login", "phone": "0911000000", "pin": "1234" }

-> 200 OK
{ "success": true, "data": { "token": "<64-hex-char opaque bearer token>",
  "expires_at": "2026-09-27 12:00:00" }, "message": "Login successful",
  "v": "1.1.0" }
```
Rate-limited: 5 failed attempts per phone in 15 minutes, 20 per IP in 1 hour,
both returning HTTP 429.

### `ep_send`
```
POST /api/v2_verify.php   Authorization: Bearer <token>
{ "action": "ep_send", "receiver": "0922000000", "amount": 150.00,
  "currency": "ETB", "note": "Lunch" }

-> 200 OK
{ "success": true, "data": { "tx_ref": "EP-A1B2C3D4E5F6", "amount": 150.00,
  "currency": "ETB", "receiver_phone": "+251922000000",
  "receiver_name": "Test User", "note": "Lunch" }, "message": "Transfer successful",
  "v": "1.1.0" }
```
Fails with 400 "Insufficient balance" at the pre-check, or a 500 "concurrent
change" message if a race is caught by the guarded `UPDATE`.

### `ep_partner_credit` (server-to-server)
```
POST /api/v2_verify.php   X-Etel-Key: <EP_SECRET_FINAL>
{ "action": "ep_partner_credit", "phone": "0933000000", "amount": 250.00,
  "partner": "delivery", "partner_ref": "DEL-DRIVER-PAYOUT-2026-09-20-001",
  "note": "Driver earnings payout" }

-> 200 OK
{ "success": true, "data": { "tx_ref": "EP-B2C3D4E5F6A1", "amount": 250.00,
  "phone": "+251933000000" }, "message": "Credited", "v": "1.1.0" }
```
A retried call with the same `partner`+`partner_ref` returns
`{"idempotent_replay": true, ...}` instead of crediting twice. Fails with 400
above the 3000 ETB per-call cap, or 429 above the 20000 ETB rolling 24-hour cap.

### `service_nfc_charge.php` (standalone, server-to-server)
```
POST /api/service_nfc_charge.php   X-Etel-Service-Key: <ETELID_SERVICE_KEY>
{ "receiver_phone": "+251911000000", "payer_phone": "+251922000000",
  "amount": 45.00, "note": "Coffee" }

-> 200 OK
{ "success": true, "data": { "tx_ref": "NFC1A2B3C4D5E6F", "amount": 45.00,
  "currency": "ETB" } }
```
Called by EtelID only after both parties have independently verified their own
EtelID password on-device. Response shape is flat (no `v` field) since this
script does not go through `v2_verify.php`'s `ep_ok()` helper. Fails 402 on
insufficient balance, 404 if either phone has no wallet, 403 if either wallet
is suspended.

## External interface contracts

| System | Actions/files | Auth |
|---|---|---|
| EtelID SSO | `ep_login_etelid` | User-driven redirect/exchange flow |
| EtelID KYC bridge | `etelid_kyc.php`, `ep_etelid_kyc_sync` | Outbound TLS-verified call |
| EtelID Members Controller | `etelid_member_detail.php`, `etelid_members_list.php` | Shared service key |
| EtelID wallet-status check | `service_check_wallet.php` (excludes balance fields by design) | Shared service key |
| EtelID NFC bridge | `service_nfc_charge.php` | Shared service key |
| Partner systems (e.g. Delivery & Ride) | `ep_partner_credit`, `ep_platform_transfer`, `ep_verify_tx` | Shared service key (`EP_SECRET_FINAL`) |
| Telegram Bot API | `ep_send_tg_otp` | Bot token (server-side), rate-limited + format-checked on the caller-facing side |
| Telebirr | Top-up gateway integration | Gateway-specific credentials |
