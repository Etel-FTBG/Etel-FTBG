# 05 — Security Controls (Implementation Level)

This section documents concrete implementation-level security controls as
they exist in EtelPay's own codebase. Full findings/fixes narrative is in the
companion Security Documentation.

## 1. Authentication

- Real, server-side, database-backed opaque bearer tokens — not a
  self-encoding JWT/HMAC scheme. `ep_login` generates
  `bin2hex(openssl_random_pseudo_bytes(32))` (genuinely random, not
  derived from any signable/forgeable input) and inserts a row into
  `ep_sessions` mapping the token to the user and an expiry.
- `ep_auth()` validates by joining `ep_sessions` to `ep_users` on the exact
  token string and requiring `expires_at > NOW()`. Since the token carries no
  embedded data, revoking access means deleting the DB row — there is no
  forgeable-token class of bug here at all.
- 7-day hard expiry plus (added during the security review) an 8-hour
  idle-inactivity timeout, tracked via a `last_active_at` column refreshed on
  every successful `ep_auth()` call.
- Real server-side revocation on logout (deletes that session), PIN change
  (deletes every session for that user, forcing re-login on every device),
  and admin-initiated account deletion (same, for the target user).
- Account-suspension status is re-checked on every authenticated request, not
  only at login — an admin suspension takes effect on the user's very next
  call even with an unexpired token.
- No cookie-based session exists anywhere in this codebase — confirmed by
  direct grep, zero `setcookie()` calls.
- Login brute-force protection: 5 failed attempts per phone per 15 minutes,
  20 failed attempts per IP per hour, backed by a self-healing
  `ep_login_attempts` table — genuinely wired into `ep_login`, not merely
  defined and unused. The same limiter was extended, during the security
  review, to `ep_send_tg_otp` (previously unauthenticated and unlimited).

## 2. Authorization

- No client-supplied "role" or "is_admin" field anywhere — `is_admin` is read
  everywhere but never written by any client-facing action; the only ways an
  account becomes an admin are a direct database change or the
  `admin_phones` setting fallback (itself only writable by an
  already-admin-gated action).
- `_ep_require_admin()` is the single admin gate used by all 20
  `ep_admin_*`/`ep_analytics` actions — checks the session's `is_admin`
  column first, falling back to the `admin_phones` setting, never trusting a
  request-body field.
- IDOR/ownership scoping verified across every user-facing action: balance,
  history, profile, PIN change, avatar, analytics, payment-link listing, and
  API-key listing all resolve the acting user's own ID from the session
  token, never from a request parameter; API-key revoke and top-up confirm
  are explicitly scoped `WHERE id/ref=? AND user_id=?`.
- Service-to-service auth (partner credit/platform transfer, the four
  standalone scripts) uses shared-secret `hash_equals()` comparisons,
  independent of the bearer-token system, with the money-moving actions in
  `ep_r1.php` now comparing against `EP_SECRET_FINAL` (a safe, auto-derived
  fallback) rather than the raw, placeholder-shippable `EP_SECRET` constant.
- `service_check_wallet.php` deliberately excludes balance fields from its
  response — a documented, intentional privacy boundary for a caller (e.g. a
  roadside NFC check) that has no legitimate need to see a member's wallet
  balance.

## 3. Injection Prevention

- All database access uses PDO parameterized queries with
  `PDO::ATTR_EMULATE_PREPARES => false`, set independently in each of this
  codebase's four PDO-construction sites.
- The only place a variable is concatenated directly into a query string is
  table names, always drawn from a `define()`d constant sourced from
  configuration, never from request input.
- Dynamic column lists (`ep_qr_generate`'s INSERT, `ep_admin_save_settings`'s
  key whitelist) always draw field *names* from a hardcoded candidate list or
  whitelist array — only the *values* bound into the resulting placeholders
  come from the request.
- `updater-api.php`'s `run_sql` action is a deliberate, admin-tool exception
  allowing an authenticated operator to run arbitrary SQL — a documented
  capability of the tool itself, gated by the Updater password (fixed during
  the security review to reject the shipped placeholder).

## 4. Output Encoding (XSS Prevention)

- A single, consistently-applied escaping helper (`EP_CORE.esc()` in
  `js/core.js`) is used everywhere a field that could contain another user's
  free text is placed into `innerHTML` — verified across ~90 sink occurrences
  in the admin panel, transaction history, and other pages.
- Places that display another user's name/text via `.textContent =` are safe
  by construction regardless of content.
- `diag.html`'s raw `JSON.stringify()`-into-`innerHTML` dump (a developer-only
  diagnostics console, not linked from normal navigation) now applies a local
  escaping helper as of the security review's second pass.

## 5. File Upload Handling

- `ep_upload_avatar`: 500KB decoded-size cap; PNG detected by magic-byte
  signature, and (as of the security review's second pass) JPEG is also
  verified by its own magic bytes (`FF D8 FF`) rather than assumed for any
  non-PNG upload; the stored file extension is always one of two hardcoded
  values, never client-supplied, and the filename is fully server-generated.
- `ep_kyc_submit`: all three image fields (front document, back document,
  selfie) now carry the same ~3MB application-layer size cap — extended to
  the back document and selfie during the security review's second pass;
  previously only the front document was capped.
- `updater-api.php`'s file-deploy path whitelists destination extensions and
  uses `realpath()`-based traversal checks; `config.php` and `.env` are
  hardcoded into a protected-files list and can never be overwritten by any
  Updater action.

## 6. Rate Limiting

- `ep_login_attempts` table plus rate-limit helper functions, applied to
  `ep_login` (keyed by phone and by IP) and, as of the security review, to
  `ep_send_tg_otp` as well.

## 7. Error Handling & Logging

- Diagnostic actions (`ep_diag_db`, `ep_diag_sessions`, `ep_diag_telebirr`)
  are now admin-gated — previously they carried a comment claiming
  admin-only/IP-gated status that the code never actually implemented.
- `etelid_members_list.php`'s debug-fingerprint response (leaking part of
  the real shared service key on a mismatch) was removed.
- `updater-api.php`'s deploy-audit-log write failure is now surfaced via
  `error_log()` instead of being silently swallowed.
- `ep_db()`'s connection-failure handler returns a generic message, never
  the underlying exception text (which could echo DSN/credential details).

## 8. Web-Server-Level Controls

- `Etel.Pay/wallet/backups/` (222 real timestamped deploy backups already
  present in this repo checkout) now has its own explicit deny-all
  `.htaccess` plus `Options -Indexes` — previously unprotected and directly
  fetchable by guessable/enumerable filename.
- `api/.htaccess` protects `config.php`/`.env` by filename within `api/`.

## 9. Payment Integrity

- Every real balance debit uses an atomic conditional `UPDATE ... WHERE
  balance >= ?` plus a row-count check inside a transaction, applied
  identically across `ep_send`, `ep_escrow_send`, `ep_qr_process`,
  `ep_platform_transfer`, and the standalone `service_nfc_charge.php`.
- `ep_partner_credit`/`ep_platform_transfer` require a caller-supplied
  idempotency key (`partner_ref`), enforced unique by a real DB constraint
  and reserved via an `INSERT` before any balance moves, plus a per-call cap
  and a rolling 24-hour cap per partner.
- Admin refund/reverse/approve actions (`ep_admin_dispute_resolve`'s refund
  branch, `ep_admin_reverse_tx`, `ep_admin_topup_approve`) all use an atomic
  status-flip-then-credit pattern, preventing a retried or double-clicked
  request from double-processing the same transaction, dispute, or top-up.
