# 01 — Database Schema

EtelPay uses its own MySQL database, independent of every sibling Etel Group
system. Unlike Delivery & Ride's numbered-migration history, EtelPay's schema
is self-healing: tables and columns are created/altered lazily at runtime by
the code that first needs them (e.g. `etelid_kyc.php`'s `ALTER TABLE ... ADD
COLUMN` probe pattern, `ep_r1.php`'s `ep_qr_generate` column-existence probe,
and the `last_active_at` column added to `ep_sessions` in the same lazy-healing
style during the second security-review pass). There is no dedicated
migrations directory in this codebase.

## Table inventory

| Table | Key columns | Purpose |
|---|---|---|
| `ep_users` | id, phone (unique), pin_hash, full_name, balance_etb, balance_usd, is_admin, kyc_status, status, avatar_url | Wallet accounts. `is_admin` is read everywhere but never written by any client-facing action — the only ways an account becomes an admin are a direct database change or the `admin_phones` setting fallback (itself only writable by an already-admin-gated action). |
| `ep_sessions` | token (opaque, 256-bit random), ep_user_id, expires_at, last_active_at | Bearer-token sessions. `last_active_at` (added during the security review's second pass) backs an 8-hour idle-inactivity timeout, checked and refreshed on every `ep_auth()` call, in addition to the pre-existing 7-day hard expiry. |
| `ep_transactions` | tx_ref, sender/receiver user IDs, amount, currency, note, status | All money movements: sends, escrow, partner credits, platform transfers, NFC charges. |
| `ep_qr_codes` | amount, currency, label, expires_at, status, used, owner | QR payment codes. |
| `ep_rates` | currency pair, rate | Exchange rates, admin-editable. |
| `ep_settings` | key, value | Platform settings; writes restricted to a hardcoded whitelist (`platform_name`, `support_phone`, `support_email`, `daily_limit`, `platform_fee`) — the request body only ever supplies the value, never the key name used in the query. |
| `ep_updater_logs` | timestamp, action, operator | Updater tool audit trail. Its write helper (`upd_log()`) now calls `error_log()` on a failed write instead of silently swallowing it (fixed during the security review). |
| `ep_login_attempts` | phone, ip, timestamp | Brute-force/rate-limit tracking, shared by `ep_login` and (as of this review) `ep_send_tg_otp`. |
| `ep_api_keys` | id, user_id, key value, created_at, revoked | Partner/developer API credentials, scoped by `user_id`; revoke is scoped `WHERE id=? AND user_id=?` so one member cannot revoke another's key even by guessing an ID. |
| `ep_kyc` | user_id, doc_type, doc_front, doc_back, selfie, status, reviewer_note | KYC submissions, stored as `LONGTEXT` base64. All three image fields now carry the same ~3MB application-layer size cap (extended to `doc_back`/`selfie` during the security review's second pass; previously only `doc_front` was capped). |
| `ep_disputes` | id, tx_ref, reason, status | Dispute records. The `refund` resolution path now uses an atomic status-flip guard (`UPDATE ... SET status='resolved' WHERE id=? AND status IN ('open','investigating')`, proceeding to move money only if a row was actually affected) — added during the security review to prevent a retried or double-clicked resolution from double-crediting. |
| `ep_topup_requests` | ref (unique per user), user_id, amount, status | Top-up initiation/confirmation records, scoped to the caller's own request by `ref` + `user_id`. |

## Notable design distinctions from sibling systems

- No shared `users` table with any other Etel Group system — `ep_users` is
  EtelPay's own table, entirely separate from Delivery & Ride's `users` table
  or EtelID's member table.
- No migrations directory; schema evolution happens via lazy, idempotent
  runtime probes rather than versioned SQL migration files.
- `ep_sessions` stores a genuinely random opaque token, not a self-verifying
  signed value — there is nothing to decode or forge; validity is determined
  entirely by whether a matching, unexpired, non-idle row exists in the table.
