# 03 — State Machines

## 3.1 Session Lifecycle

```
  ep_login / ep_login_etelid (success)
              |
              v
   ep_sessions row created: token, expires_at (+7 days), last_active_at (now)
              |
              v
   every ep_auth() call:
     - reject 401 if expires_at <= NOW()               (hard 7-day cap)
     - reject 401 if NOW() - last_active_at > 8 hours   (idle timeout, added
                                                          during security review)
     - reject 403 if ep_users.status != 'active'        (checked every call,
                                                          not just at login)
     - otherwise: refresh last_active_at, proceed
              |
              v
   ep_logout                      ep_change_pin (success)         ep_admin_delete_user
   deletes THIS session's row     deletes ALL sessions for        deletes ALL sessions
                                  that user (every device)         for the target user
```

No token-refresh action exists anywhere in this codebase — expiry (hard cap or
idle timeout) always produces a clean 401 requiring a fresh login, with no
silent-refresh fallback path.

## 3.2 Top-Up (two-step, single approval)

```
  ep_topup_initiate (member starts a top-up)
              |
              v
       ep_topup_requests row created, status = 'pending'
       (member pays via Telebirr or other channel outside the app)
              |
              v
  ep_topup_confirm (member submits payment reference,
                     scoped to WHERE ref=? AND user_id=? —
                     cannot confirm another member's request)
              |
              v
  ep_admin_topup_approve (admin, separate step, idempotent status-flip guard)
              |
              v
       status = 'approved' -> balance credited
```

## 3.3 Dispute Resolution (refund path — idempotency added during security review)

```
  ep_dispute_open (member opens a dispute against a tx_ref + reason)
              |
              v
       ep_disputes row created, status = 'open'
              |
              v
  ep_admin_dispute_resolve (admin, refund or reject)
              |
   refund branch:                          reject branch:
   UPDATE ep_disputes SET status='resolved'  status = 'rejected'
   WHERE id=? AND status IN
   ('open','investigating')
              |
      only if UPDATE affected a row:
      credit original sender, debit receiver
              |
      (a second call on an already-resolved
      dispute now fails cleanly instead of
      moving money again)
```

Before this fix, the refund branch read the dispute with a plain `SELECT`,
credited/debited unconditionally, and only updated `status` at the very end —
a double-click or retried request could double-process the same dispute. The
fix applies the same atomic status-flip-then-credit pattern already used by
`ep_admin_reverse_tx` and `ep_admin_topup_approve`.

## 3.4 KYC Review

```
  ep_kyc_submit (member submits doc_front, doc_back, selfie —
                 all three now size-capped at ~3MB as of this review;
                 previously only doc_front was capped)
              |
              v
       ep_kyc row created, status = 'pending'
              |
              v
  ep_admin_kyc_review (admin, approve or reject with reviewer_note)
              |
              v
       status = 'approved' / 'rejected'
```

## 3.5 Money-Movement Concurrency Guard (applies to every debit site)

```
  BEGIN TRANSACTION
      UPDATE ep_users
      SET balance_etb = balance_etb - ?
      WHERE id = ? AND balance_etb >= ?
      -- if ROW_COUNT() = 0: ROLLBACK, fail "Insufficient balance (concurrent change)"
      -- if ROW_COUNT() = 1: proceed to credit the counterparty, record the
      --                     transaction row, COMMIT
```
Applied identically at every real debit site in this codebase: `ep_send`,
`ep_escrow_send`, `ep_qr_process`, `ep_platform_transfer`, and the standalone
`service_nfc_charge.php` — preventing two concurrent debits from both passing
an earlier balance pre-check and over-spending the same balance.
