# Technical Design Document / Low-Level Design (TDD/LLD)
## EtelPay Platform — v1.0

Prepared for Etel Group's cyber-security audit application to INSA, submitted via
the Hibir platform. Companion to the SRS and SDD documents.

## Scope note

EtelPay is an independently deployed system with its own database and its own
single dispatch entrypoint (`api/v2_verify.php`) — it does not share a backend
with any sibling Etel Group system (unlike Etel Ride and Etel Delivery, which do
share one backend). This document describes only EtelPay's own schema, API
surface, and modules. Where EtelPay depends on an external system (EtelID for
identity, partner systems for server-to-server wallet credit), that is stated
explicitly as an external interface rather than shared internal infrastructure.

## Contents

1. `01_Database_Schema.md` — table inventory
2. `02_API_Contracts.md` — route-handler/action inventory
3. `03_State_Machines.md` — session, top-up, dispute, and KYC lifecycle state machines
4. `04_Module_Breakdown.md` — file-level module map
5. `05_Security_Controls.md` — implementation-level security mechanisms

All content in this package is derived directly from the production source code
at `Etel.Pay/wallet/` in the Etel-FTBG repository, cross-verified against the
project's internal security review (`docs/INSA_FINDINGS_EtelPay.md`). No content
here is speculative — every claim is traceable to a specific file, table, or
action name in the codebase.
